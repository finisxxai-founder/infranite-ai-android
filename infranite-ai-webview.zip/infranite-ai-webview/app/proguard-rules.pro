# Add project specific ProGuard rules here.
# For more details, see http://developer.android.com/guide/developing/tools/proguard.html

# --- WebView JavaScript bridge -----------------------------------------------
# R8 can strip or rename methods that are only ever called via JavaScript
# reflection, silently breaking the bridge in release builds while debug
# builds (unminified) keep working. This keeps it intact.
-keepclassmembers class com.infranite.app.webview.WebAppInterface {
    public *;
}
-keepattributes JavascriptInterface

# --- General WebView / JS reflection safety ---------------------------------
-keepattributes *Annotation*

# --- AndroidX / Material consumer rules are bundled in their AARs, no extra
# rules are needed for core-ktx, appcompat, material, or the splash screen
# library.
