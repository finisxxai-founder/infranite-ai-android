package com.infranite.app.webview

import android.content.Context
import android.content.Intent
import android.webkit.JavascriptInterface

/**
 * Bridges the Web Share API to a native Android share sheet.
 *
 * WebView does not implement `navigator.share()` on its own, so MainActivity injects a
 * small JS shim (see injectShareShim()) that calls Android.share(...) when the page tries
 * to use it. Only this one method is exposed, and it carries @JavascriptInterface as
 * required — without that annotation Android refuses to expose any method to JS (API 17+).
 */
class WebAppInterface(private val context: Context) {

    @JavascriptInterface
    fun share(title: String?, text: String?, url: String?) {
        val body = listOfNotNull(text, url).joinToString(separator = "\n").ifBlank { title.orEmpty() }
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, body)
            if (!title.isNullOrBlank()) putExtra(Intent.EXTRA_SUBJECT, title)
        }
        context.startActivity(Intent.createChooser(sendIntent, null))
    }
}
