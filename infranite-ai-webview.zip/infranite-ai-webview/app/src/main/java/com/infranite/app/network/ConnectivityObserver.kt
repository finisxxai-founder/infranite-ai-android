package com.infranite.app.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper

/**
 * Thin wrapper around ConnectivityManager.NetworkCallback.
 *
 * Two things this exists to get right:
 *  - NetworkCallback methods fire on a background thread, so results are posted back to
 *    the main looper before invoking the lambdas — callers can safely touch views in them.
 *  - start()/stop() are idempotent and meant to be called from onStart()/onStop(), so the
 *    callback is never left registered past the Activity's visible lifetime (a classic
 *    ConnectivityManager leak if you forget to unregister).
 */
class ConnectivityObserver(
    context: Context,
    private val onAvailable: () -> Unit,
    private val onLost: () -> Unit
) {
    private val connectivityManager: ConnectivityManager? =
        context.applicationContext.getSystemService(ConnectivityManager::class.java)

    private val mainHandler = Handler(Looper.getMainLooper())
    private var registered = false

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            mainHandler.post(onAvailable)
        }

        override fun onLost(network: Network) {
            mainHandler.post(onLost)
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            if (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            ) {
                mainHandler.post(onAvailable)
            }
        }
    }

    fun start() {
        if (registered) return
        val manager = connectivityManager ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        manager.registerNetworkCallback(request, callback)
        registered = true
    }

    fun stop() {
        if (!registered) return
        connectivityManager?.unregisterNetworkCallback(callback)
        registered = false
    }

    fun isCurrentlyOnline(): Boolean {
        val manager = connectivityManager ?: return false
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
