package com.infranite.app.download

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Listens for DownloadManager.ACTION_DOWNLOAD_COMPLETE.
 *
 * DownloadManager already shows its own in-progress/completion notification, but with a
 * generic system icon. This receiver reports the finished download back to MainActivity so
 * it can post one additional, properly-branded notification with a tap-to-open action.
 */
class DownloadCompleteReceiver(
    private val onDownloadFinished: (downloadId: Long, success: Boolean, title: String, uri: Uri?) -> Unit
) : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        if (downloadId == -1L) return

        val downloadManager = context.getSystemService(DownloadManager::class.java) ?: return
        val cursor = downloadManager.query(DownloadManager.Query().setFilterById(downloadId)) ?: return

        cursor.use {
            if (!it.moveToFirst()) return
            val statusIndex = it.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val titleIndex = it.getColumnIndex(DownloadManager.COLUMN_TITLE)
            val status = if (statusIndex >= 0) it.getInt(statusIndex) else -1
            val title = (if (titleIndex >= 0) it.getString(titleIndex) else null).orEmpty()
            val success = status == DownloadManager.STATUS_SUCCESSFUL
            val uri = if (success) downloadManager.getUriForDownloadedFile(downloadId) else null
            onDownloadFinished(downloadId, success, title, uri)
        }
    }
}
