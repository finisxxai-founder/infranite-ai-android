package com.infranite.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.color.DynamicColors
import com.infranite.app.databinding.ActivityMainBinding
import com.infranite.app.download.DownloadCompleteReceiver
import com.infranite.app.network.ConnectivityObserver
import com.infranite.app.webview.WebAppInterface

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var connectivityObserver: ConnectivityObserver

    private val targetHost: String? = Uri.parse(BuildConfig.TARGET_URL).host
    private val appWebChromeClient = AppWebChromeClient()

    private var pendingFilePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermissionRequest: PermissionRequest? = null
    private var pendingGeolocationOrigin: String? = null
    private var pendingGeolocationCallback: GeolocationPermissions.Callback? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var isPageReady = false

    private val downloadReceiver = DownloadCompleteReceiver { _, success, title, uri ->
        postDownloadNotification(success, title, uri)
    }

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            val results: Array<Uri>? = if (result.resultCode == RESULT_OK && data != null) {
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
            } else null
            pendingFilePathCallback?.onReceiveValue(results)
            pendingFilePathCallback = null
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            val allGranted = grants.values.all { it }
            pendingPermissionRequest?.let { req -> if (allGranted) req.grant(req.resources) else req.deny() }
            pendingPermissionRequest = null
            pendingGeolocationCallback?.invoke(pendingGeolocationOrigin, allGranted, false)
            pendingGeolocationCallback = null
            pendingGeolocationOrigin = null
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* best-effort */ }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        DynamicColors.applyToActivityIfAvailable(this)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        splashScreen.setKeepOnScreenCondition { !isPageReady }
        splashScreen.setOnExitAnimationListener { provider ->
            provider.view.animate().alpha(0f).setDuration(300L)
                .withEndAction { provider.remove() }
                .start()
        }
        // Safety net: never hold the splash screen indefinitely, even if the page is slow
        // to report itself ready or something unexpected happens.
        Handler(Looper.getMainLooper()).postDelayed({ isPageReady = true }, SPLASH_HOLD_TIMEOUT_MS)

        setupEdgeToEdge()
        createDownloadNotificationChannel()
        registerDownloadReceiver()
        configureWebView()
        setupErrorScreen()
        setupBackNavigation()

        connectivityObserver = ConnectivityObserver(
            context = this,
            onAvailable = { if (binding.errorLayout.visibility == View.VISIBLE) retryLoad() },
            onLost = { /* showError() is driven by the WebView's own load failure, not by
                          transient capability flicker, to avoid false positives */ }
        )

        if (savedInstanceState != null) {
            binding.webView.restoreState(savedInstanceState)
        } else {
            handleShareIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        connectivityObserver.start()
    }

    override fun onStop() {
        connectivityObserver.stop()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        binding.webView.onResume()
        binding.webView.resumeTimers()
    }

    override fun onPause() {
        binding.webView.onPause()
        binding.webView.pauseTimers()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        binding.webView.saveState(outState)
    }

    override fun onDestroy() {
        connectivityObserver.stop()
        try {
            unregisterReceiver(downloadReceiver)
        } catch (e: IllegalArgumentException) {
            // already unregistered — safe to ignore
        }
        binding.webView.apply {
            (parent as? ViewGroup)?.removeView(this)
            stopLoading()
            webChromeClient = null
            webViewClient = object : WebViewClient() {}
            removeJavascriptInterface("Android")
            destroy()
        }
        super.onDestroy()
    }

    // region Setup

    private fun setupEdgeToEdge() {
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val errorTop = binding.errorLayout.paddingTop
        val errorBottom = binding.errorLayout.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(binding.errorLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(top = errorTop + bars.top, bottom = errorBottom + bars.bottom)
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.progressBar) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(top = bars.top)
            insets
        }
        // The wrapped site declares viewport-fit=cover and handles safe-area-inset-* itself,
        // so the WebView is intentionally left unpadded and draws fully edge-to-edge.
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        binding.webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            // Secure defaults: the site is HTTPS-only, so mixed content is fully blocked
            // and the WebView never needs to touch file:// URLs directly.
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            setGeolocationEnabled(true)
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) {
            WebSettingsCompat.setSafeBrowsingEnabled(binding.webView.settings, true)
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(binding.webView, true)
        }

        binding.webView.webViewClient = AppWebViewClient()
        binding.webView.webChromeClient = appWebChromeClient
        binding.webView.addJavascriptInterface(WebAppInterface(this), "Android")
        binding.webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(url, userAgent, contentDisposition, mimeType)
        }

        binding.swipeRefresh.setOnRefreshListener { binding.webView.reload() }
    }

    private fun setupErrorScreen() {
        binding.retryButton.setOnClickListener { retryLoad() }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this) {
            when {
                binding.fullscreenContainer.visibility == View.VISIBLE -> appWebChromeClient.onHideCustomView()
                binding.webView.canGoBack() -> binding.webView.goBack()
                else -> {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        }
    }

    // endregion

    // region Navigation / errors

    private fun handleShareIntent(receivedIntent: Intent?) {
        if (receivedIntent?.action == Intent.ACTION_SEND && receivedIntent.type == "text/plain") {
            val shared = receivedIntent.getStringExtra(Intent.EXTRA_TEXT)?.trim()
            if (shared != null && (shared.startsWith("http://") || shared.startsWith("https://"))) {
                binding.webView.loadUrl(shared)
                return
            }
        }
        binding.webView.loadUrl(BuildConfig.TARGET_URL)
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            Toast.makeText(this, R.string.cannot_open_link, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showError() {
        binding.errorLayout.visibility = View.VISIBLE
        binding.swipeRefresh.visibility = View.GONE
        binding.progressBar.visibility = View.GONE
        binding.swipeRefresh.isRefreshing = false
    }

    private fun hideError() {
        if (binding.errorLayout.visibility == View.VISIBLE) {
            binding.errorLayout.visibility = View.GONE
            binding.swipeRefresh.visibility = View.VISIBLE
        }
    }

    private fun retryLoad() {
        hideError()
        binding.webView.reload()
    }

    private fun injectShareShim() {
        val script = """
            (function() {
                if (!navigator.share) {
                    navigator.share = function(data) {
                        try {
                            var d = data || {};
                            Android.share(d.title || null, d.text || null, d.url || null);
                            return Promise.resolve();
                        } catch (e) {
                            return Promise.reject(e);
                        }
                    };
                }
            })();
        """.trimIndent()
        binding.webView.evaluateJavascript(script, null)
    }

    // endregion

    // region Downloads & notifications

    private fun createDownloadNotificationChannel() {
        val channel = NotificationChannel(
            DOWNLOAD_CHANNEL_ID,
            getString(R.string.download_channel_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = getString(R.string.download_channel_description)
        }
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }

    private fun registerDownloadReceiver() {
        ContextCompat.registerReceiver(
            this,
            downloadReceiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun startDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        try {
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mimeType)
                addRequestHeader("User-Agent", userAgent)
                setTitle(fileName)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                setAllowedOverMetered(true)
            }
            getSystemService(DownloadManager::class.java)?.enqueue(request)
            Toast.makeText(this, getString(R.string.download_started, fileName), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.download_failed_toast, Toast.LENGTH_SHORT).show()
        }
    }

    private fun postDownloadNotification(success: Boolean, title: String, uri: Uri?) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val builder = NotificationCompat.Builder(this, DOWNLOAD_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setAutoCancel(true)

        if (success) {
            builder.setContentTitle(getString(R.string.download_complete_title))
                .setContentText(getString(R.string.download_complete_text, title))
            if (uri != null) {
                val openIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, contentResolver.getType(uri))
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val pendingIntent = PendingIntent.getActivity(
                    this, uri.hashCode(), openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                builder.setContentIntent(pendingIntent)
            }
        } else {
            builder.setContentTitle(getString(R.string.download_failed_title))
                .setContentText(getString(R.string.download_failed_text, title))
        }

        NotificationManagerCompat.from(this).notify(title.hashCode(), builder.build())
    }

    // endregion

    // region Fullscreen video

    private fun enterImmersiveMode() {
        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun exitImmersiveMode() {
        WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    // endregion

    private inner class AppWebViewClient : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = request.url
            return if (uri.host == targetHost) {
                false
            } else {
                openExternal(uri)
                true
            }
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            hideError()
        }

        override fun onPageCommitVisible(view: WebView?, url: String?) {
            super.onPageCommitVisible(view, url)
            isPageReady = true
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            binding.swipeRefresh.isRefreshing = false
            injectShareShim()
        }

        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            super.onReceivedError(view, request, error)
            if (request?.isForMainFrame == true) {
                isPageReady = true
                showError()
            }
        }

        override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler, error: SslError?) {
            // Secure default: never proceed past a certificate error.
            handler.cancel()
            isPageReady = true
            showError()
        }
    }

    private inner class AppWebChromeClient : WebChromeClient() {

        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            binding.progressBar.progress = newProgress
            binding.progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
        }

        override fun onShowFileChooser(
            webView: WebView?,
            callback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            pendingFilePathCallback?.onReceiveValue(null)
            pendingFilePathCallback = callback
            val chooserIntent = fileChooserParams?.createIntent()
                ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
            return try {
                fileChooserLauncher.launch(chooserIntent)
                true
            } catch (e: Exception) {
                pendingFilePathCallback = null
                false
            }
        }

        override fun onPermissionRequest(request: PermissionRequest) {
            val needed = request.resources.mapNotNull {
                when (it) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
                    else -> null
                }
            }
            if (needed.isEmpty()) {
                request.grant(request.resources)
                return
            }
            val notGranted = needed.filter {
                ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
            }
            if (notGranted.isEmpty()) {
                request.grant(request.resources)
            } else {
                pendingPermissionRequest = request
                permissionLauncher.launch(notGranted.toTypedArray())
            }
        }

        override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
            val fineGranted = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarseGranted = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (fineGranted || coarseGranted) {
                callback.invoke(origin, true, false)
                return
            }
            pendingGeolocationOrigin = origin
            pendingGeolocationCallback = callback
            permissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden()
                return
            }
            customView = view
            customViewCallback = callback
            binding.fullscreenContainer.addView(
                view,
                FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            )
            binding.fullscreenContainer.visibility = View.VISIBLE
            binding.swipeRefresh.visibility = View.GONE
            enterImmersiveMode()
        }

        override fun onHideCustomView() {
            val view = customView ?: return
            binding.fullscreenContainer.removeView(view)
            binding.fullscreenContainer.visibility = View.GONE
            binding.swipeRefresh.visibility = View.VISIBLE
            customView = null
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
            exitImmersiveMode()
        }

        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
            // Links that try to open in a new window (target="_blank", window.open(), OAuth
            // sign-in popups) are handed to the system browser instead of a second in-app
            // WebView — this is also how Google expects OAuth to be handled from a WebView.
            val transportView = WebView(this@MainActivity)
            transportView.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                    openExternal(request.url)
                    return true
                }
            }
            val transport = resultMsg?.obj as? WebView.WebViewTransport
            transport?.webView = transportView
            resultMsg?.sendToTarget()
            return true
        }
    }

    companion object {
        private const val DOWNLOAD_CHANNEL_ID = "downloads"
        private const val SPLASH_HOLD_TIMEOUT_MS = 3000L
    }
}
