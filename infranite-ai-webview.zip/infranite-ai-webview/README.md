# Infranite AI — Android WebView App

A native **Kotlin/Android** app (Gradle + AndroidManifest.xml + `.kt` sources — not Flutter;
there's no Dart or `pubspec.yaml` in this project) that wraps **https://infranite-ai.lovable.app**
in a full-featured WebView.

## Two workflow files

There are now two workflows under `.github/workflows/`, and both trigger on every push to
`main`, so a single push kicks off both runs:
- **`build.yml`** — debug APK only, using the `chmod +x gradlew` / `./gradlew assembleDebug`
  pattern, no secrets involved at all. This is the one described below.
- **`build-release.yml`** — builds debug + release APK + release AAB, with release signing
  that activates automatically once you add the four signing secrets (see "Release build"
  further down); until then it also just falls back to debug signing.

They're redundant for the debug APK specifically (you'll get two copies, from two separate
runs). Harmless, just a little wasteful — say the word if you'd rather I trim
`build-release.yml` down to release-only so each workflow has one clear job.

## Fastest path to a Debug APK (no keystore needed)

Debug builds are signed automatically by Android's own built-in debug key — nothing to
generate, nothing to configure. The only thing you need is a real Android build environment,
which GitHub Actions provides for free:

1. Push this whole folder to a new GitHub repository.
2. Open the **Actions** tab — the workflow runs automatically (or click **Run workflow**).
3. When it finishes (~2 minutes), open the run and scroll to **Artifacts** →
   download **`infranite-ai-debug-apk`** (from `build-release.yml`) or **`app-debug`** (from
   `build.yml`) — both are the same `app-debug.apk`, just from the two separate workflow runs
   described above.
4. Copy it to your phone and tap to install (you'll need to allow "install unknown apps"
   for whichever app you transfer it through, since it's not from the Play Store).

That workflow run *is* the real compiler — its log is the real build log, and the job
summary it writes is the real build summary. See "About verification" below for why that
matters.

Prefer a local build? Open the project folder in **Android Studio**, let it sync, then
either hit the green ▶ **Run** button with your phone connected, or
**Build → Build APK(s)**. No signing setup needed for a debug build either way.

## Implemented features

| Area | Status |
|---|---|
| Splash screen (animated logo, brand color) | ✅ |
| Pull-to-refresh | ✅ |
| Loading progress bar | ✅ |
| Offline screen with Retry, auto-reload when back online | ✅ |
| Back button navigates WebView history | ✅ |
| Full-screen HTML5 video | ✅ |
| File upload (`<input type="file">`, camera + gallery) | ✅ |
| Download manager, with a branded "download complete" notification | ✅ |
| Share: site can call `navigator.share()`; other apps can share a link into this app | ✅ |
| External links (payment providers, OAuth sign-in, etc.) open in the system browser | ✅ |
| Material 3 theming, dynamic color on Android 12+ | ✅ |
| Light/dark mode | ✅ |
| Edge-to-edge display | ✅ |
| Adaptive app icon + proper monochrome notification icon | ✅ |
| Safe Browsing, blocked mixed content, SSL errors fail closed (never "proceed anyway") | ✅ |
| WebView leak-safe teardown, paused timers while backgrounded | ✅ |

## Permissions

| Permission | Declared | Requested at runtime | Trigger |
|---|---|---|---|
| Internet / network state | ✅ | n/a (normal permission) | always |
| Camera | ✅ | ✅ | site calls `getUserMedia({video: true})` |
| Microphone | ✅ | ✅ | site calls `getUserMedia({audio: true})` |
| Location | ✅ | ✅ | site calls the Geolocation API |
| Notifications | ✅ | ✅ | right before the first download starts |
| Storage (legacy, API ≤28 only) | ✅ | n/a below API 29 | needed only for old-device downloads |

Camera/gallery **file uploads** and **downloads** don't need extra permissions at all —
they go through Android's system file picker and DownloadManager, which have their own
access grants independent of the app.

**Deliberately not added:** broad photo/video/audio library permissions
(`READ_MEDIA_IMAGES`/`VIDEO`/`AUDIO`) and Bluetooth.
- The file-picker flow above already covers "camera upload / gallery upload" completely
  without them — adding unused dangerous permissions is exactly what Play Store review
  flags, and there's no code path in this app that would use them.
- WebView (unlike desktop Chrome) doesn't implement the Web Bluetooth API at all, on any
  Android version — so a Bluetooth permission would be inert dead weight, not a working
  feature.

If your site needs one of these for something the file picker doesn't cover, tell me what
specifically and I'll wire up the real (contextual) permission flow for it.

## About verification

I don't have the Android SDK or internet access in the sandbox I write code in — I've
checked this directly (no `sdkmanager`/`gradle`/`adb`, no network for this tool), so I
can't run Gradle myself and hand you a compiled `.apk`, a real build log, or a real build
summary from this chat. What I *can* do, and did, is validate everything I have the tools
for: every XML resource file is well-formed, every brace/paren in the Kotlin and Gradle
files balances, and every resource reference (`R.string.*`, `R.drawable.*`, view IDs,
manifest theme/xml references) resolves to something that's actually declared — that rules
out the most common source of build failures, but it isn't the same as a real compile.
The GitHub Actions run in the quick-start above *is* the real compile, with a real Android
toolchain and real internet access to fetch it. If a run fails, paste me the failing step's
log and I'll fix it.

## Release build (for later — not needed for a debug APK)

A signing keystore for `assembleRelease`/`bundleRelease` was already generated
(`infranite-release.jks`, alias `infranite`) and is being shared as a separate file, not
inside this zip, so it's never accidentally committed to git. To use it:
1. Add four repo secrets under **Settings → Secrets and variables → Actions**:
   `KEYSTORE_BASE64` (the file, base64-encoded), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (`infranite`),
   `KEY_PASSWORD` (same as the store password — modern PKCS12 keystores use one password
   for both).
2. Push again — the release job in the same workflow will pick up the secrets automatically
   and produce a properly-signed `app-release.apk` and `app-release.aab`. Until those secrets
   exist, the release build falls back to debug signing so it still produces an installable
   file rather than failing.
3. Keep the `.jks` file and its password somewhere private (password manager, not git).
   Play Store publishing uses Play App Signing, so this upload key can be reset later
   through Google if it's ever lost.

## Customizing

| What | Where |
|---|---|
| Target URL | `TARGET_URL` in `app/build.gradle` (`buildConfigField`) |
| App name | `app_name` in `res/values/strings.xml` |
| Package ID | `namespace` / `applicationId` in `app/build.gradle` |
| Brand color | `brand_primary` in `res/values/colors.xml` and `res/values-night/colors.xml` |
| App icon | `res/drawable/ic_launcher_background.xml` / `ic_launcher_foreground.xml` |
